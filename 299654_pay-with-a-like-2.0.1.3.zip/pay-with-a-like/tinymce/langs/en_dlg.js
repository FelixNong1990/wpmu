tinyMCE.addI18n("en.paywithalike", {
	title: "Pay With a Like"
});