<h2><?php _e('Custom Site Generator Content','ub'); ?></h2>
<p>
<?php _e('By Default WordPress identifies itself as the site generator on all your network sites. You can use the options on this page to change the site generator and generator link to your own brand and site url.','ub'); ?>
</p>