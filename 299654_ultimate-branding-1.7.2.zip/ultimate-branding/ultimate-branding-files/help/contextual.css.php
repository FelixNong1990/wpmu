<h2><?php _e('Custom Admin CSS' ,'ub'); ?></h2>
<p>
<?php _e('Any CSS styles added to this area will be included in the header of all the admin pages on all the sites across your network. You can use this to hide elements, or simply change the color of menus and / or text.','ub'); ?>
</p>
<h3><?php _e('Custom Login CSS' ,'ub'); ?></h3>
<p>
<?php _e('Any CSS styles added to this area will be included in the header of the login pages on all the sites across your network. It can be used to add backgrounds or customize the login page for your network.','ub'); ?>
</p>