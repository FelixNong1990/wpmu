<h2><?php _e('Remove Permalinks Menu','ub'); ?></h2>
<p>
<?php _e('The Remove Permalinks Menu module does not have any settings, it simply removes the Permalinks menu from all of the sites on your network.','ub'); ?>
</p>