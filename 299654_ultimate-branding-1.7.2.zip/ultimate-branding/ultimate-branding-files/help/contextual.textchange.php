<h2><?php _e('Network Wide Text Change','ub'); ?></h2>
<p>
<?php _e('This module allows you to change any item of text across WordPress with text of your own. It is useful if you want to, for example, remove the word WordPress from any of the menus of text and replace it with your own brand.','ub'); ?>
</p>
<p>
<?php _e('If you want to limit the text change to within a certain plugin or theme, then you need to find the text domain for that plugin / theme and enter that in the area labelled <strong>in this text domain</strong>. E.G. The text domain for this plugin is <strong>ub</strong>.','ub'); ?>
</p>