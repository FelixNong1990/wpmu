<h2><?php _e('Ultimate Branding Dashboard','ub'); ?></h2>
<p>
<?php _e('The Ultimate Branding Dashboard allows you to decide which branding modules you wish to have enabled across your network.','ub'); ?>
</p>
<p>
<?php _e('To enable a module, simply click on the Enable link next to the modules name. The settings for that module can then be controlled via the newly added tab at the top of the Brandin administration page.','ub'); ?>
</p>