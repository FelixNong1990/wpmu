jQuery(document).ready(function($){
    $('.ultimate-color-field').wpColorPicker();
});