<?php

class Eab_Widget extends WP_Widget {
    /**
     * @var		string	$translation_domain	Translation domain
     */
    var $translation_domain = 'eab';
}
