<?php
/*
Plugin Name: Remove Permalinks Menu Item
Plugin URI: http://premium.wpmudev.org/project/remove-permalinks-menu-item
Description: Removes the 'permalinks' configuration options
Author: Andrew Billits, Ulrich Sossou
Version: 1.0.3
Author URI: http://premium.wpmudev.org/
WDP ID: 171
*/

add_action( 'admin_menu', 'remove_permalinks_menu_item' );

function remove_permalinks_menu_item() {
	global $submenu;
	unset( $submenu['options-general.php'][40] );
}


/**
 * Show notification if WPMUDEV Update Notifications plugin is not installed
 **/
if ( !function_exists( 'wdp_un_check' ) ) {
	add_action( 'admin_notices', 'wdp_un_check', 5 );
	add_action( 'network_admin_notices', 'wdp_un_check', 5 );

	function wdp_un_check() {
		if ( !class_exists( 'WPMUDEV_Update_Notifications' ) && current_user_can( 'edit_users' ) )
			echo '<div class="error fade"><p>' . __('Please install the latest version of <a href="http://premium.wpmudev.org/project/update-notifications/" title="Download Now &raquo;">our free Update Notifications plugin</a> which helps you stay up-to-date with the most stable, secure versions of WPMU DEV themes and plugins. <a href="http://premium.wpmudev.org/wpmu-dev/update-notifications-plugin-information/">More information &raquo;</a>', 'wpmudev') . '</p></div>';	  	  	  		  		   	
	}
}