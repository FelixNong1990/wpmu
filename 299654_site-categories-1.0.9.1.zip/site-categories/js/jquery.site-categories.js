jQuery(document).ready(function($) {
	jQuery( "#site-categories-wrapper .site-categories-accordion" ).accordion({ heightStyle: 'content', header: '.site-categories-accordion-header' });
});