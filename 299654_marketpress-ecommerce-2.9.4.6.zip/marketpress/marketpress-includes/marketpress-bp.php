<?php
/*
MarketPress BP Features
*/

class MarketPress_BP {

  function __construct() {


	}

  function install() {

  }

}
$mp_bp = &new MarketPress_BP();