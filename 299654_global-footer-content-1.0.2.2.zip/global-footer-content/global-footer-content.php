<?php
/*
Plugin Name: Global Footer Content
Plugin URI: http://premium.wpmudev.org/project/global-footer-content
Description: Simply insert any code that you like into the footer of every blog
Author: S H Mohanjith (Incsub), Andrew Billits (Incsub)
Version: 1.0.2.2
Author URI: http://premium.wpmudev.org
Network: true
WDP ID: 93
*/

/*
Copyright 2007-2009 Incsub (http://incsub.com)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License (Version 2 - GPLv2) as published by
the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

global $global_footer_content_settings_page, $global_footer_content_settings_page_long;

if ( version_compare($wp_version, '3.0.9', '>') ) {
	$global_footer_content_settings_page = 'settings.php';
	$global_footer_content_settings_page_long = 'network/settings.php';
} else {
	$global_footer_content_settings_page = 'ms-admin.php';
	$global_footer_content_settings_page_long = 'ms-admin.php';
}

//------------------------------------------------------------------------//
//---Hook-----------------------------------------------------------------//
//------------------------------------------------------------------------//
add_action('init', 'global_footer_content_init');
add_action('admin_menu', 'global_footer_content_plug_pages');
add_action('network_admin_menu', 'global_footer_content_plug_pages');
add_action('wp_footer', 'global_footer_content');
//------------------------------------------------------------------------//
//---Functions------------------------------------------------------------//
//------------------------------------------------------------------------//

function global_footer_content_init() {
	if ( !is_multisite() )
	add_action('admin_notices', 'not_multisite_compatible');

	load_plugin_textdomain('global_footer_content', false, dirname(plugin_basename(__FILE__)).'/languages');
}

function not_multisite_compatible() { ?>
	<div id="message" class="error">
		<p><?php _e('The Global Footer Content plugin is only compatible with WordPress Multisite. Sorry.', 'global_footer_content'); ?></p>
	</div>
<?php }

function global_footer_content_plug_pages() {
	global $wpdb, $wp_roles, $current_user, $wp_version, $global_footer_content_settings_page, $global_footer_content_settings_page_long;
	if ( version_compare($wp_version, '3.0.9', '>') ) {
	    if ( is_network_admin() ) {
		add_submenu_page($global_footer_content_settings_page, __('Global Footer Content', 'global_footer_content'), __('Global Footer Content', 'global_footer_content'), 'manage_network_options', 'global_footer_content', 'global_footer_content_site_admin_options');
	    }
	} else {
	    if ( is_site_admin() ) {
		add_submenu_page($global_footer_content_settings_page, __('Global Footer Content', 'global_footer_content'), __('Global Footer Content', 'global_footer_content'), 'manage_network_options', 'global_footer_content', 'global_footer_content_site_admin_options');
	    }
	}
}

//------------------------------------------------------------------------//
//---Output Functions-----------------------------------------------------//
//------------------------------------------------------------------------//

function global_footer_content() {
	$global_footer_content = get_site_option('global_footer_content');
	if ( $global_footer_content == 'empty' ) {
		$global_footer_content = '';
	}
	if ( !empty( $global_footer_content ) ) {
		echo stripslashes( $global_footer_content );
	}
}

function global_footer_content_site_admin_options() {
	global $wpdb, $wp_roles, $current_user, $global_footer_content_settings_page;

	$global_footer_content = get_site_option('global_footer_content');
	if ( $global_footer_content == 'empty' ) {
		$global_footer_content = '';
	}

	if(!current_user_can('manage_options')) {
		echo "<p>" . __('Nice Try...', 'global_footer_content') . "</p>";  //If accessed properly, this message doesn't appear.
		return;
	}
	if (isset($_GET['updated'])) {
		?><div id="message" class="updated fade"><p><?php _e(urldecode($_GET['updatedmsg']), 'global_footer_content') ?></p></div><?php
	}
	echo '<div class="wrap">';
	switch( $_GET[ 'action' ] ) {
		//---------------------------------------------------//
		default:
	?>
	<form method="post" action="<?php print $global_footer_content_settings_page; ?>?page=global_footer_content&action=process">
		<h2><?php _e('Footer Content', 'global_footer_content') ?></h2>
		<table class="form-table">
			<tr valign="top">
				<th scope="row"><?php _e('Footer Content', 'global_footer_content') ?></th>
				<td>
                	<textarea name="global_footer_content" id="global_footer_content" rows="5" cols="45" style="width: 95%;" ><?php echo stripslashes( $global_footer_content ); ?></textarea>
					<br />
					<?php _e('Added to the footer content of every blog page. Useful for statistics embeds, etc.', 'global_footer_content') ?>
				</td>
			</tr>
		</table>

		<p class="submit">
			<input class="button button-primary" type="submit" name="Submit" value="<?php _e('Save Changes', 'global_footer_content') ?>" />
			<input class="button button-secondary" type="submit" name="Reset" value="<?php _e('Reset', 'global_footer_content') ?>" />
		</p>
        </form>
	<?php
	break;
	case "process":
			if ( isset( $_POST[ 'Reset' ] ) ) {
				update_site_option( 'global_footer_content' , "empty" );
				echo "
				<SCRIPT LANGUAGE='JavaScript'>
				window.location='{$global_footer_content_settings_page}?page=global_footer_content&updated=true&updatedmsg=" . urlencode(__('Changes saved.', 'global_footer_content')) . "';
				</script>
				";
			} else {
				$global_footer_content = $_POST['global_footer_content'];
				if ( $global_footer_content == '' ) {
					$global_footer_content = 'empty';
				}

				update_site_option( 'global_footer_content' , $global_footer_content );
				echo "
				<SCRIPT LANGUAGE='JavaScript'>
				window.location='{$global_footer_content_settings_page}?page=global_footer_content&updated=true&updatedmsg=" . urlencode(__('Changes saved.', 'global_footer_content')) . "';
				</script>
				";
			}
		break;
	}
	echo '</div>';
}

global $wpmudev_notices;
$wpmudev_notices[] = array( 'id'=> 93, 'name'=> 'Global Footer Content', 'screens' => array( 'settings_page_global_footer_content-network' ) );
include_once(plugin_dir_path( __FILE__ ).'external/dash-notice/wpmudev-dash-notification.php');