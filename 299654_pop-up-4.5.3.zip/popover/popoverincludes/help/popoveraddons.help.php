<h2><?php _e('Introduction','popover'); ?></h2>
<p><?php _e('Add-ons allow you to extend the Pop Over plugin. The Add-on screen lists all of the Add-ons currently installed. To activate or deactivate an Add-on you should click on the Activate or Deactivate link underneath the Add-ons title.','popover'); ?></p>
<p><?php popover_helpimage('addonslist.png'); ?></p>