The Double Opt-in email can now be customized to a specific locale.

If your locale is "en_US" then eNewsletter will look for the file in this folder called double_optin-en_US.html.

If that file is not found it will default back to double_optin.html

If you are having trouble determining your local code use the wordpress function get_locale();


299654-1401501181