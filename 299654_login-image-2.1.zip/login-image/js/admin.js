jQuery(document).ready(function()
{
    jQuery('#wp_login_image_button').click(function()
    {
        wp.media.editor.send.attachment = function(props, attachment)
        {
            jQuery('#wp_login_image').val(attachment.url);
            jQuery('#wp_login_image_id').val(attachment.id);
            jQuery('#wp_login_image_size').val(props.size);
            //document.login_image_form.submit();
        }
        wp.media.editor.open(this);
        return false;
    });
});

