jQuery(document).ready(function($) {
	
	$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
	// postboxes setup
	postboxes.add_postbox_toggles('avhfdas-wrap');
});