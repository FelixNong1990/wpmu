<?php
/**
 * Renders form elements for admin settings pages.
 */
class AVH_Asirra_AdminFormRenderer extends AVH_FormsRenderer {
	protected $_option_name;
	protected $_pfx;
	protected $_opts;

	public function __construct () {
		$this->_option_name = 'avhfdas-asirra';
		$this->_pfx = 'avh-asirra';
		parent::__construct();
	}

	function create_position_box () {
		$positions = array(
			"top" => __("Top", 'avh-fdas'),
			"bottom" => __("Bottom", 'avh-fdas'),
			"left" => __("Left", 'avh-fdas'),
			"right" => __("Right", 'avh-fdas'),
		);
		foreach ($positions as $pos => $label) {
			echo
				$this->_create_radiobox('position', $pos) .
				"&nbsp;<label for='position-{$pos}'>{$label}</label><br />" .
			'';
		}
	}

	function create_cells_box () {
		$cells = array_combine(range(2,12), range(2,12));
		printf(__('Show %s images per row', 'avh-fdas'), $this->_create_keyval_selection_box('cells', $cells));
	}

	function create_disable_box () {
		echo $this->_create_checkbox('disable_asirra');
		echo '<div><small>' . __('Asirra protection is enabled by default. If you set this option, your comments will <b>NOT</b> be protected by Asirra challenge.', 'avh-fdas') . '</small></div>';
	}

}