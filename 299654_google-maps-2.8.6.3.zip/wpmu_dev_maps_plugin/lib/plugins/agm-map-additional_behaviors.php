<?php
/*
Plugin Name: Additional Behaviors
Description: Exposes additional map default behaviors.
Plugin URI:  http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version:     1.0
Author:      Ve Bailovity (Incsub)
*/

class Agm_Mab_AdditionalBehaviors {

	private function __construct () {}

	public static function serve () {
		$me = new Agm_Mab_AdditionalBehaviors;
		$me->_add_hooks();
	}

	private function _add_hooks () {
		add_action('agm_google_maps-load_user_scripts', array($this, 'load_scripts'));
		add_filter('agm_google_maps-javascript-data_object-user', array($this, 'add_behaviors_data'));

		add_action('agm_google_maps-options-plugins_options', array($this, 'register_settings'));
	}

	function load_scripts () {
		wp_enqueue_script('additional_behaviors-user', AGM_PLUGIN_URL . '/js/mab-additional_behaviors.js', array('jquery'));
	}

	function add_behaviors_data ($data) {
		$data['additional_behaviors'] = $this->_get_options();
		return $data;
	}

	function register_settings () {
		add_settings_section('agm_google_maps_mab', __('Additional Behaviors', 'agm_google_maps'), array($this, 'create_section'), 'agm_google_maps_options_page');
		add_settings_field('agm_google_maps_list_kmls', __('Behaviors', 'agm_google_maps'), array($this, 'create_behaviors_box'), 'agm_google_maps_options_page', 'agm_google_maps_mab');
	}

	function create_section () {
		echo '<p><em>' . __('This is where you can define additional global settings for your maps.', 'agm_google_maps') . '</em></p>';
	}

	function create_behaviors_box () {
		$opts = $this->_get_options();
		echo '' .
			'<label for="agm_google_maps-mab-marker_click_popup">' .
				'<input type="hidden" value="" name="agm_google_maps[mab][marker_click_popup]" />' .
				'<input type="checkbox" value="1" id="agm_google_maps-mab-marker_click_popup" name="agm_google_maps[mab][marker_click_popup]" ' . checked($opts['marker_click_popup'], true, false) . ' />' .
				'&nbsp' .
				__('Clicking on marker from the list opens its popup', 'agm_google_maps') .
			'</label>' .
		'<br />';
		echo '' .
			'<label for="agm_google_maps-mab-directions_click_scroll">' .
				'<input type="hidden" value="" name="agm_google_maps[mab][directions_click_scroll]" />' .
				'<input type="checkbox" value="1" name="agm_google_maps[mab][directions_click_scroll]" id="agm_google_maps-mab-directions_click_scroll" ' . checked($opts['directions_click_scroll'], true, false) . ' />' .
				'&nbsp' .
				__('Clicking on directions link scrolls to directions interface', 'agm_google_maps') .
			'</label>' .
		'<br />';
	}

	private function _get_options () {
		$opts = apply_filters('agm_google_maps-options', get_option('agm_google_maps'));
		$opts = isset($opts['mab']) && $opts['mab'] ? $opts['mab'] : array();
		return wp_parse_args($opts, array(
			'directions_click_scroll' => false,
			'marker_click_popup' => false,
		));
	}


}

Agm_Mab_AdditionalBehaviors::serve();