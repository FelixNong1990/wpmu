<?php
/*
Plugin Name: BuddyPress member map *BETA*
Description: New shortcode <code>[agm_members_map]</code> to display a global map with the location of all BuddyPress members.
Plugin URI:  http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version:     1.0
Author:      Hoang Ngo (Incsub)
Requires:    BuddyPress
*/


if ( defined( 'BP_PLUGIN_DIR' ) ) :

	class Agm_GlobalMap_AdminPages {
		public static function serve() {
			$me = new Agm_GlobalMap_AdminPages;
			$me->_add_hooks();
		}

		private function _add_hooks() {
			add_action( 'agm_google_maps-options-plugins_options', array( $this, 'register_settings' ) );
		}

		public function register_settings() {
			add_settings_section(
				'agm_google_global_map_fields',
				__( 'BuddyPress member map', 'agm_google_maps' ),
				array( $this, 'create_dependencies_box' ),
				'agm_google_maps_options_page'
			);
		}

		public function create_dependencies_box() {
			_e( 'Place the shortcode <code>[agm_members_map]</code> to the page you want to map display.', 'agm_google_maps' );
		}
	}

	class Agm_GlobalMap_UserPages {
		private $_model;

		public function __construct() {
			$this->_model = new AgmMapModel;
		}

		public static function serve() {
			$me = new Agm_GlobalMap_UserPages;
			$me->_add_hooks();
		}

		private function _add_hooks() {
			add_shortcode(
				'agm_members_map',
				array( $this, 'global_map' )
			);
		}

		public function global_map() {
			$users = get_users(
				array(
					'meta_key'     => 'agm-bp-profile_maps-location',
					'meta_value'   => null,
					'meta_compare' => '!=',
					'fields'       => array( 'ID' )
				)
			);

			$markers = array();
			foreach ( $users as $user ) {
				$markers[] = $this->member_to_marker( $user->ID );
			}
			//show up
			return $this->_create_map( $markers );
		}

		/**
		 * Creates a map from a list of markers.
		 */
		private function _create_map( $markers, $id = false, $overrides = array() ) {
			if ( ! $markers ) {
				return false;
			}
			$id = $id ? $id : md5( time() . rand() );

			$map = $this->_model->get_map_defaults();
			$map['defaults'] = $this->_model->get_map_defaults();
			$map['id'] = $id;
			$map['show_map'] = 1;
			$map['show_markers'] = 0;
			$map['markers'] = $markers;

			$codec = new AgmMarkerReplacer();
			return $codec->create_tag( $map, $overrides );
		}

		public function member_to_marker( $member_id ) {
			$location = get_user_meta(
				$member_id,
				'agm-bp-profile_maps-location',
				true
			);
			return $location;
		}
	}


	if ( is_admin() ) {
		Agm_GlobalMap_AdminPages::serve();
	} else {
		Agm_GlobalMap_UserPages::serve();
	}

endif;