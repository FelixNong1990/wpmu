<?php
/*
Plugin Name: Custom Icons
Description: Enable this add-on to add your own map marker icons!
Plugin URI:  http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version:     1.0
Author:      Philipp Stracker (Incsub)
*/

class Agm_Icons_AdminPages {

	private function __construct() {}

	/**
	 * Initialize the Admin interface.
	 *
	 * @since 1.0
	 */
	public static function serve() {
		$me = new Agm_Icons_AdminPages();
		$me->_add_hooks();
	}

	/**
	 * Attach the hooks for the admin-page
	 *
	 * @since 1.0
	 */
	private function _add_hooks() {
		// Load the javascript that provides new map options.
		add_action(
			'admin_enqueue_scripts',
			array( $this, 'load_scripts' )
		);

		// Add our own options to the plugin config page.
		add_action(
			'agm_google_maps-options-plugins_options',
			array( $this, 'register_settings' )
		);
	}

	/**
	 * Add new section to the plugin config page
	 *
	 * @since  1.0
	 */
	public function register_settings() {
		add_settings_section(
			'agm_google_maps_icons',
			__( 'Custom icons', 'agm_google_maps' ),
			create_function( '', '' ),
			'agm_google_maps_options_page'
		);

		add_settings_field(
			'agm_google_maps_icon_add',
			__( 'Add new icons', 'agm_google_maps' ),
			array( $this, 'render_settings_box_add' ),
			'agm_google_maps_options_page',
			'agm_google_maps_icons'
		);

		add_settings_field(
			'agm_google_maps_icon_list',
			__( 'Custom icons', 'agm_google_maps' ),
			array( $this, 'render_settings_box_icons' ),
			'agm_google_maps_options_page',
			'agm_google_maps_icons'
		);
	}

	/**
	 * Renders the settings where user can preview and delete custom icons.
	 *
	 * @since  1.0
	 */
	public function render_settings_box_icons() {
		$options = get_option( 'agm_google_maps' );
		$iconlist = @$options['custom_icons'];
		?>
		<table class="icons widefat" cellspacing="0" cellpadding="0">
			<?php foreach ( array( 'thead', 'tfoot' ) as $tag ) : ?>
			<<?php echo esc_attr( $tag ); ?>>
				<tr>
					<th style="width:5%"><?php _e( 'Icon', 'agm_google_maps' ); ?></th>
					<th style="width:75%"><?php _e( 'URL', 'agm_google_maps' ); ?></th>
					<th style="width:15%"><?php _e( 'Width x Height', 'agm_google_maps' ); ?></th>
					<th style="width:5%">&nbsp;</th>
				</tr>
			</<?php echo esc_attr( $tag ); ?>>
			<?php endforeach; ?>
			<tbody>
			</tbody>
		</table>
		<input type="hidden" name="agm_google_maps[custom_icons]" class="custom-icon-list" value="<?php echo esc_attr( $iconlist ); ?>" />
		<?php
	}

	/**
	 * Renders the settings where user can add new custom icons.
	 *
	 * @since  1.0
	 */
	public function render_settings_box_add() {
		?>
		<div>
			<label for="custom-icon"><?php _e( 'Icon URL', 'agm_google_maps' ); ?>:</label>
			<input type="url" class="custom-icon-url" id="custom-icon" value="" style="display:block;width:100%" placeholder="http://..." maxlength="1024" />
		</div>
		<div>
			<span style="float: left"><img src="" class="custom-icon-preview marker-icon-32" /></span>
			<button type="button" class="add-custom-icon button disabled" disabled="disabled"
				data-enabled="<?php _e( 'Add this icon', 'agm_google_maps' ); ?>"
				data-disabled="<?php _e( 'Enter a valid image URL', 'agm_google_maps' ); ?>"
				>
			</button>
		</div>
		<br />
		<div style="clear: both">
			<button type="button" class="add-media-image button"><?php _e( 'Add icon from media library', 'agm_google_maps' ); ?></button>
		</div>
		<br />
		<div>
			<em><?php _e( 'Note: All icons will be displayed in full-size on the map. In the editor and this list the icon-preview is displayed with 32 x 32 pixels.', 'agm_google_maps' ); ?></em>
		</div>
		<?php
	}

	/**
	 * Load the javascript file that provides new map options.
	 *
	 * @since 1.0
	 */
	public function load_scripts( $hook ) {
		if ( 'settings_page_agm_google_maps' == $hook )  {
			wp_register_script(
				'agm-icons',
				AGM_PLUGIN_URL . '/js/icons-admin.js',
				array( 'jquery' )
			);

			wp_register_style(
				'agm-icons',
				AGM_PLUGIN_URL . '/css/icons-admin.css'
			);

			$data = array(
				'lang' => array(),
			);

			wp_localize_script( 'agm-icons', '_agmIcons', $data );
			wp_enqueue_script( 'agm-icons' );
			wp_enqueue_style( 'agm-icons' );

			wp_enqueue_media();
		}
	}

}



class Agm_Icons_Shared {

	private function __construct() {}

	/**
	 * Initialize the traffic overlay on frontend of the website.
	 *
	 * @since 1.0
	 */
	public static function serve() {
		$me = new Agm_Icons_Shared();
		$me->_add_hooks();
	}

	/**
	 * Setup all the WordPress hooks to get the overlay working.
	 *
	 * @since 1.0
	 */
	private function _add_hooks() {
		add_filter(
			'agm_google_maps-custom_icons',
			array( $this, 'load_icons' )
		);
	}

	/**
	 * Modifies the icons list: Add our custom icons!
	 *
	 * @since  1.0
	 */
	public function load_icons( $icons ) {
		$custom = $this->_get_custom_icons();
		return array_merge( $icons, $custom );
	}

	/**
	 * Returns an array of custom icons
	 *
	 * @since 1.0
	 */
	private function _get_custom_icons() {
		static $Icons = null;

		if ( null === $Icons ) {
			$options = get_option( 'agm_google_maps' );
			$iconlist = @$options['custom_icons'];
			$Icons = json_decode( $iconlist );

			if ( ! is_array( $Icons ) ) {
				$Icons = array();
			}
		}

		return $Icons;
	}

}


if ( is_admin() ) {
	Agm_Icons_AdminPages::serve();
}
Agm_Icons_Shared::serve();