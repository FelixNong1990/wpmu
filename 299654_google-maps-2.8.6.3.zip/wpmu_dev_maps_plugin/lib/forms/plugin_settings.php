<?php
$shortcode_tag = 'agm_map' == AgmMapModel::get_config( 'shortcode_map' ) ? 'agm_map' : 'map';
?>
<div class="wrap">
	<h2>Google Maps Plugin Options</h2>

	<p>
		The Google Map plugin adds a &quot;Add Map&quot; icon to your visual editor.
		Once you&apos;ve created your new map it is inserted into write Post / Page
		area as shortcode which looks like this: <code>[<?php esc_html_e( $shortcode_tag ); ?> id="1"]</code>.
	</p>
	<p>
		It also adds a widget so you can add maps to your sidebar (see Appearance &gt; Widgets).
	</p>
	<?php if ( ! is_multisite() ) : ?>
		<p>
			For more detailed instructions on how to use refer to
			<a target="_blank" href="http://premium.wpmudev.org/project/wordpress-google-maps-plugin/#usage">Google Maps Installation and Use instructions</a>.
		</p>
	<?php endif; ?>

	<?php $options = apply_filters( 'agm_google_maps-settings_form_options', '' ); ?>
	<form action="options.php" <?php echo $options; ?> method="post">
		<?php settings_fields( 'agm_google_maps' ); ?>
		<div class="vnav">
		<?php do_settings_sections( 'agm_google_maps_options_page' ); ?>
		</div>
		<p class="submit">
			<button name="Submit" class="button-primary"><?php esc_attr_e( 'Save Changes' ); ?></button>
		</p>
	</form>
</div>

<script type="text/javascript">
(function ($) {
$(function () {

	// Set up contextual help inline triggers
	$("[data-agm_contextual_trigger]").each(function () {
		var $me = $(this),
			$target = $($me.attr("data-agm_contextual_trigger"))
		;
		if (!$target.length) return false;
		$me.on("click", function () {
			$("#contextual-help-link").click();
			$target.find("a").click();
			$(window).scrollTop(0);
			return false;
		});
	});
});
})(jQuery);
</script>