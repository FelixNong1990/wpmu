jQuery(function () {
	var $doc = jQuery(document);

	// Add options
	var add_markup = function add_markup( event, el, data ) {
		var url = '';
		try { url = data.kml_url ? data.kml_url : ''; }
		catch (ignore) { url = ''; }

		el.find( '#agm_mh_options' ).append(
			'<fieldset id="agm-kml_url_overlay">' +
				'<legend>KML Overlay</legend>' +
				'<label for="agm-kml_url">KML file URL</label>' +
				'<input type="text" id="agm-kml_url" class="widefat" value="' + url + '" />' +
			'</fieldset>'
		);
	};

	// Save KML URL
	var save_data = function save_data( event, request ) {
		request.kml_url = jQuery( '#agm-kml_url' ).val();
	};

	// Load KML overlay
	var init_map = function init_map( event, map, data ) {
		var url = '';

		try { url = data.kml_url ? data.kml_url : ''; }
		catch (ignore) { url = ''; }

		jQuery( '#agm-kml_url' ).val( url );
		if ( ! url ) {
			return false;
		}

		var kml = new google.maps.KmlLayer( url );
		$doc.data( 'kml_overlay', kml );
		kml.setMap( map );
	};

	// Update hte KML overlay
	var close_dialog = function close_dialog( event, map ) {
		var oldKml = $doc.data( 'kml_overlay' );
		if ( oldKml ) {
			oldKml.setMap(null);
		}

		var url = jQuery( '#agm-kml_url' ).val();
		if ( ! url ) {
			return false;
		}

		var kml = new google.maps.KmlLayer( url );
		kml.setMap(map);
	};


	$doc.bind('agm_google_maps-admin-markup_created', add_markup );
	$doc.bind("agm_google_maps-admin-save_request", save_data );
	$doc.bind("agm_google_maps-admin-map_initialized", init_map );
	$doc.bind("agm_google_maps-admin-options_dialog-closed", close_dialog );

});
