/**
 * Plugin Name: Traffic-overlay
 * Author:      Philipp Stracker (Incsub)
 *
 * Javascript component for ADMIN page of the traffic-overlay addon.
 */

jQuery(function init_addon() {
	var $doc = jQuery( document );

	// Add the new checkbox to the maps option popup.
	var init_options = function init_options( event, el, data ) {
		var has_traffic = false;
		try {
			has_traffic = data.show_traffic ? data.show_traffic : false;
		} catch( ignore ) { }

		el.find( '#agm_mh_options' ).append(
			'<fieldset id="agm-show_traffic-box">' +
				'<legend>' + _agmTraffic.lang.show_traffic + '</legend>' +
				'<input type="checkbox" id="agm-show_traffic" value="1" />&nbsp;' +
				'<label for="agm-show_traffic">' + _agmTraffic.lang.show_traffic + '</label>' +
			'</fieldset>'
		);
		jQuery( '#agm-show_traffic' ).prop( 'checked', has_traffic );
	};

	// Set the current option value when saving the options.
	var sanitize_options = function sanitize_options( event, request ) {
		request.show_traffic = jQuery( '#agm-show_traffic' ).is( ':checked' );
	}

	// Add options.
	$doc.bind( 'agm_google_maps-admin-markup_created', init_options );

	// Save options.
	$doc.bind( 'agm_google_maps-admin-save_request', sanitize_options );
});
