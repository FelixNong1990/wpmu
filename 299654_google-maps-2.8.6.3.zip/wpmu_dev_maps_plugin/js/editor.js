/**
 * Responsible for hooking Maps to the WP editor interface.
 */


function openMapEditor () {
	jQuery(document).trigger('agm_map_editor_open');
	jQuery(window).on("resize", updateSizes);
	return false;
}

function closeMapEditor () {
	tb_remove();
	jQuery(window).off("resize", updateSizes);
	jQuery(document).trigger('agm_map_editor_close');
	return false;
}

function updateSizes () {
	var $tgt = jQuery("#TB_ajaxContent"),
		pad = $tgt.outerHeight() - $tgt.height()
	;
	$tgt.height(jQuery("#TB_window").height() - jQuery("#TB_title").height() - pad);
	$tgt.width('auto');
}


(function($){
	jQuery(function() {

	/**
	 * Individual (currently active) map handler.
	 */
	var _mapHandler = false;

	/**
	 * Requests a fresh list of existing maps from the server.
	 */
	function requestMapList () {
		var data = {
			'action': 'agm_list_maps'
		};
		jQuery.post(ajaxurl, data, loadMaps);
	}

	/**
	 * Renders the HTML for list of maps from server JSON response.
	 */
	function loadMaps (data) {
		var html = '<ul>',
			current = data.maps ? data.maps.length : 0,
			total = data.total ? parseInt(data.total, 10) : 0
		;
		$.each(data.maps, function (idx, el) {
			html += '<li class="existing_map_item">' +
				'<div class="map_item_title"><a href="#" class="edit_map_item" title="' + l10nEditor.preview_or_edit + '">' + el.title + '</a></div>' +
				'<a href="#" title="' + l10nEditor.use_this_map + '"><code class="map-shortcode add_map_item">[' + _agmConfig.shortcode + ' id="<strong>' + el.id + '</strong>"]</code></a>' +
				'<input type="hidden" value="' + el.id + '" />' +
				'<div class="map_item_actions">' +
					'<a href="#" class="edit_map_item">' + l10nEditor.preview_or_edit + '</a>' +
					'&nbsp;|&nbsp;' +
					'<a href="#" class="add_map_item">' + l10nEditor.use_this_map + '</a>' +
					'<a href="#" class="delete_map_item"><i class="dashicons dashicons-trash"></i>' + l10nEditor.delete_map + '</a>' +
				'</div>' +
			'</li>';
		});
		html += '</ul>';

		var $paging = $("#agm-paging_bar")
			$load_next = $("#agm-load_next_maps"),
			$load_prev = $("#agm-load_prev_maps"),
			incr = $paging.length ? parseInt($paging.attr("data-increment"), 10) : 0,
			next_increment = incr + 1,
			prev_increment = incr - 1
		;
		$('#maps_existing_result').html(html);

		if (total > current) {
			$('#maps_existing_result').append(
				'<div id="agm-paging_bar" data-increment="' + incr + '" />'
			);
			$paging = $("#agm-paging_bar");

			if (prev_increment >= 0) {
				$paging.append(
					'<a href="#" id="agm-load_prev_maps">' + l10nEditor.load_prev_maps + '</a>'
				);
				$load_prev = $("#agm-load_prev_maps");
				$load_prev
					.unbind("click")
					.bind("click", function () {
						$paging.attr("data-increment", prev_increment);
						$.post(ajaxurl, {
							"action": 'agm_list_maps',
							"increment": prev_increment
						}, loadMaps);
						return false;
					})
				;
			}
			$paging.append(
				'<a href="#" id="agm-load_next_maps">' + l10nEditor.load_next_maps + '</a>'
			);
			$load_next = $("#agm-load_next_maps");

			if (current) {
				$load_next
					.unbind("click")
					.bind("click", function () {
						$paging.attr("data-increment", next_increment);
						$.post(ajaxurl, {
							"action": 'agm_list_maps',
							"increment": next_increment
						}, loadMaps);
						return false;
					})
				;
			} else {
				$load_next.unbind("click").remove();
			}
		}
		if (!current && !total) $('#maps_new_switch').click();
		$(window).trigger("resize");
	}

	/**
	 * Requests deleting of a map.
	 */
	function deleteMap () {
		var mapId = $(this).parents('li').find('input:hidden').val();
		$.post(ajaxurl, {"action": "agm_delete_map", "id": mapId}, function (data) {
			requestMapList();
		});
	}

	/**
	 * Creates tag markup.
	 */
	function createMapIdMarkerMarkup( id, text ) {
		if ( ! id ) {
			return '';
		}
		if ( text && text.length ) {
			return ' [' + _agmConfig.shortcode + ' id="' + id + '"]' + text + '[/' + _agmConfig.shortcode + '] ';
		} else {
			return ' [' + _agmConfig.shortcode + ' id="' + id + '"] ';
		}
	}

	/**
	 * Handles map list item insert click.
	 */
	function insertMapItem () {
		var $me = $(this);
		var mapMarker = createMapIdMarkerMarkup($me.parents('li').find('input:hidden').val(), getSelectedText());
		updateEditorContents(mapMarker);
		closeMapEditor();
		return false;
	}

	/**
	 * Inserts the map marker into editor.
	 * Supports TinyMCE and regular editor (textarea).
	 */
	function updateEditorContents (mapMarker) {
		if (window.tinyMCE && ! $('#content').is(':visible')) {
			var text = window.tinyMCE.activeEditor.selection.getContent();
			window.tinyMCE.execCommand("mceInsertContent", true, mapMarker);
		} else {
			insertAtCursor($("#content").get(0), mapMarker);
		}
	}

	/**
	 * Returns the currently selected text of the post content
	 */
	function getSelectedText() {
		var text = '';
		if (window.tinyMCE && ! $('#content').is(':visible')) {
			text = window.tinyMCE.activeEditor.selection.getContent();
		} else {
			var field = jQuery("#content").get(0);
			// IE version
			if (undefined !== document.selection) {
				field.focus();
				var sel = document.selection.createRange();
				text = sel.text;
			}
			// Mozilla version
			else if (undefined !== field.selectionStart) {
				var startPos = field.selectionStart;
				var endPos = field.selectionEnd;
				text = field.value.substring(startPos, endPos)
			}
		}
		return text;
	}

	/**
	 * Inserts map marker into regular (textarea) editor.
	 */
	function insertAtCursor(fld, text) {
		// IE
		if (document.selection && !window.opera) {
			fld.focus();
			sel = window.opener.document.selection.createRange();
			sel.text = text;
		}
		// Rest
		else if (fld.selectionStart || fld.selectionStart == '0') {
			var startPos = fld.selectionStart;
			var endPos = fld.selectionEnd;
			fld.value = fld.value.substring(0, startPos)
			+ text
			+ fld.value.substring(endPos, fld.value.length);
		} else {
			fld.value += text;
		}
	}

	/**
	 * Ajax handler
	 */
	function display_map_details(data) {
		if (_mapHandler) {
			_mapHandler.destroy();
		}
		_mapHandler = new AgmMapHandler("#map_preview_container", data);
	}

	/**
	 * Loads a map and opens it for preview/editing.
	 */
	function updateMapPreview () {
		var id = jQuery(this).parents('li').find('input').val();
		jQuery.post(
			ajaxurl,
			{
				"action": 'agm_load_map',
				"id": id
			},
			display_map_details
		);
		jQuery('#maps_new_switch_container').hide();
		jQuery('#maps_existing').hide();
		jQuery('#maps_new').hide();
	}

	/**
	 * Opens a fresh map.
	 */
	function createMap () {
		jQuery.post(
			ajaxurl,
			{
				"action": 'agm_new_map'
			},
			display_map_details
		);
		jQuery('#maps_new_switch_container').hide();
		jQuery('#maps_existing').hide();
		jQuery('#maps_new').hide();
	}

	function advancedModeOn () {
		$('li.existing_map_item').each(function () {
			var $me = $(this);
			var mid = $me.find('input:hidden').val();
			var adv = jQuery('<div class="map_advanced_checkbox_container">' +
				'<input type="checkbox" class="map_advanced_checkbox" value="' + mid + '" />' +
				'<div style="clear:both"></div>' +
			'</div>');
			$me.addClass('advanced-mode');
			jQuery('.map_advanced_checkbox', adv).click(function() {
				if(jQuery(this).prop('checked')) {
					$me.addClass('selected');
				} else {
					$me.removeClass('selected');
				}
			})
			$me.prepend(adv);
		});
		var html = '<span id="advanced_mode_buttons">' +
			'<input type="button" class="button-secondary action" id="maps_merge_locations" value="' + l10nEditor.merge_locations + '" />' +
			'<input type="button" class="button-secondary action" id="maps_batch_delete" value="' + l10nEditor.batch_delete + '" />' +
		'</span>';
		$('#maps_advanced_container').append(html);
		$('#maps_advanced_mode_help_container').html(l10nEditor.advanced_mode_help);
		$('#maps_advanced_switch').val(l10nEditor.advanced_off);

		// Bind events
		$('#maps_merge_locations').click(function () {
			var mapIds = [];
			$('li.existing_map_item .map_advanced_checkbox:checked').each(function () {
				mapIds[mapIds.length] = $(this).val();
			});
			$.post(ajaxurl, {"action": "agm_merge_maps", "ids": mapIds}, function (data) {
				$('#maps_advanced_switch').click(); // Turn off advanced mode
				if (_mapHandler) _mapHandler.destroy();
				_mapHandler = new AgmMapHandler("#map_preview_container", data);
				$('#maps_existing').hide();
				$('#maps_new').hide();
			});
		});
		$('#maps_batch_delete').click(function () {
			var mapIds = [];
			$('li.existing_map_item .map_advanced_checkbox:checked').each(function () {
				mapIds[mapIds.length] = $(this).val();
			});
			$.post(ajaxurl, {"action": "agm_batch_delete", "ids": mapIds}, function (data) {
				$('#maps_advanced_switch').click(); // Turn off advanced mode
				requestMapList();
			});
		});

	}

	function advancedModeOff () {
		$('.map_advanced_checkbox_container').remove();
		$('#advanced_mode_buttons').remove();
		$('li.existing_map_item.selected').removeClass('selected');
		$('li.existing_map_item.advanced-mode').removeClass('advanced-mode');
		$('#maps_merge_locations').unbind('click');
		$('#maps_batch_delete').unbind('click');
		$('#maps_advanced_mode_help_container').html(l10nEditor.advanced_mode_activate_help);
		$('#maps_advanced_switch').val(l10nEditor.advanced);
	}


	// Find Media Buttons strip and add the new one
	var mbuttons_container = $('#media-buttons').length ? /*3.2*/ $('#media-buttons') : /*3.3*/ $("#wp-content-media-buttons");
	if ( ! mbuttons_container.length ) {
		return;
	}

	mbuttons_container.append('' +
		'<a onclick="return openMapEditor();" title="' + l10nEditor.google_maps + '" class="thickbox button" id="add_map" href="#TB_inline?width=640&inlineId=map_container">' +
			'<img onclick="return false;" alt="' + l10nEditor.google_maps + '" src="' + _agm.root_url + '/img/system/globe-button.gif">' +
		'</a>'
	);

	// Create the needed editor container HTML
	$('body').append(
		'<div id="map_container" style="display:none">' +
		(_agm.is_multisite ? '' : '<p class="agm_less_important">For more detailed instructions on how to use refer to <a target="_blank" href="http://premium.wpmudev.org/project/wordpress-google-maps-plugin/#usage">WPMU DEV Maps Installation and Use instructions</a>.</p>') +
			'<div id="maps_new_switch_container">' +
				'<p><input type="button" class="button-secondary action" id="maps_new_switch" value="' + l10nEditor.new_map + '" /></p>' +
				'<div class="agm_less_important">' + l10nEditor.new_map_intro + '</div>' +
			'</div>' +
			'<div class="agm_container" id="maps_existing">' +
				'<h3>' + l10nEditor.existing_map + '</h3>' +
				'<div id="maps_existing_result"><img src="' + _agm.root_url + '/img/system/loading.gif" />' + l10nEditor.loading + '</div>' +
				'<p id="maps_advanced_container"><button type="button" class="button-secondary action" id="maps_advanced_switch"><i class="dashicons dashicons-admin-tools"></i> ' + l10nEditor.advanced + '</button></p>' +
				'<p id="maps_advanced_mode_help_container" class="agm_less_important">' + l10nEditor.advanced_mode_activate_help + '</p>' +
			'</div>' +
			'<div class="agm_container" id="maps_new">' +
				'<h3>' + l10nEditor.new_map + '</h3>' +
			'</div>' +
			'<div id="map_preview_container"><div id="map_preview"></div></div>' +
		'</div>'
	);


	// --- Bind events ---



	// Link switching
	function show_existing_maps() {
		if (_mapHandler) {
			_mapHandler.destroy();
		}
		jQuery('#maps_new').hide();
		jQuery('#maps_existing').show();
		jQuery('#maps_new_switch_container').show();

		if (jQuery.browser.webkit) {
			jQuery('#map_preview_container')
				.css('height', 0)
				.css('width', 0)
			;
		}

		// Load fresh map list on Existing Maps tab selection
		requestMapList();
	};

	$('#maps_new_switch').click(function () {
		if (_mapHandler) _mapHandler.destroy();
		$('#maps_new_switch_container').hide();
		$('#maps_existing').hide();
		$('#maps_new').show();

		if ($.browser.webkit) {
			$('#map_preview_container')
				.css('height', 0)
				.css('width', 0)
			;
		}

		createMap();

	});

	$(document).bind('agm_map_editor_open', function () {
		show_existing_maps();
	});

	// On map addition, update editor.
	jQuery('body').on("click", "li.existing_map_item .add_map_item", insertMapItem);
	jQuery('body').on("click", "li.existing_map_item .edit_map_item", updateMapPreview);
	jQuery('body').on("click", "li.existing_map_item .delete_map_item", deleteMap);

	// Bind map closing event to list toggling
	jQuery('#map_preview_container').bind('agm_map_close', function () {
		show_existing_maps();
	});

	// Bind map editor insert event to map insert
	jQuery('#map_preview_container').bind('agm_map_insert', function (e, id) {
		var mapMarker = createMapIdMarkerMarkup(id);
		updateEditorContents(mapMarker);
		closeMapEditor();
	});

	// Bind advanced mode switching
	jQuery('#maps_advanced_switch').toggle(advancedModeOn, advancedModeOff);

	// Highlight the active existing map item
	jQuery('body')
		.on('mouseover', 'li.existing_map_item', function () { jQuery(this).addClass('agm_active_item'); })
		.on('mouseout', 'li.existing_map_item', function () { jQuery(this).removeClass('agm_active_item'); })
	;

	});
})(jQuery);