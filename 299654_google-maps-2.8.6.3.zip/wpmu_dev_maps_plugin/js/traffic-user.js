/**
 * Plugin Name: Traffic-overlay
 * Author:      Philipp Stracker (Incsub)
 *
 * Javascript component for the traffic-overlay addon.
 */

jQuery(function init_addon() {
	var $doc = jQuery( document );

	var init_overlay = function init_overlay( event, map, data ) {
		var traffic_layer, has_traffic = false;
		try {
			has_traffic = data.show_traffic ? data.show_traffic : false;
		} catch( ignore ) {}

		if ( has_traffic ) {
			traffic_layer = new google.maps.TrafficLayer();
			traffic_layer.setMap( map );
		}
	};

	$doc.bind( 'agm_google_maps-user-map_initialized', init_overlay );
});
