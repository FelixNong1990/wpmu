(function ($) {

function directions_click_scroll (e, position, marker, $container) {
	var $directions = $container.find(".agm_mh_directions_container");
	if (!$directions.length) return false;
	$(window).scrollTo($directions.offset().top);
}

function marker_click_popup (e, marker, map) {
	marker._agmInfo.open(map, marker);
}

$(function () {
	var data = _agm.additional_behaviors || {};
	if (data.directions_click_scroll) $(document).on("agm_google_maps-user-directions-waypoint_populated", directions_click_scroll);
	if (data.marker_click_popup) $(document).on("agm_google_maps-user-map_centered_to_marker", marker_click_popup);
});
})(jQuery);