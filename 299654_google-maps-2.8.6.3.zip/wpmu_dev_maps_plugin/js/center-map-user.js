jQuery(function () {
	var $doc = jQuery( document );

	// Center map
	var center_map = function center_map( event, map, data ) {
		var center = false, lat = false, lng = false;

		if ( undefined != data.center ) {
			center = data.center;

			try { lat = parseFloat(center.latitude); }
			catch ( ex ) { lat = false; }
			try { lng = parseFloat(center.longitude); }
			catch ( ex ) { lng = false; }
		} else if ( undefined != data.map_center ) {
			center = data.map_center;

			try { lat = parseFloat(center[0]); }
			catch ( ex ) { lat = false; }
			try { lng = parseFloat(center[1]); }
			catch ( ex ) { lng = false; }
		}

		if ( ! lat || ! lng ) {
			return false;
		}

		map.setCenter( new google.maps.LatLng( lat, lng ) );
	};

	$doc.bind( 'agm_google_maps-user-map_initialized', center_map );
});
