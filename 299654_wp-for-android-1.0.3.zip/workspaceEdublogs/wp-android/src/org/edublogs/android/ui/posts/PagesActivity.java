package org.edublogs.android.ui.posts;

import org.edublogs.android.ui.posts.PostsActivity;

public class PagesActivity extends PostsActivity {
    // Exists to distinguish pages from posts in menu drawer

}
