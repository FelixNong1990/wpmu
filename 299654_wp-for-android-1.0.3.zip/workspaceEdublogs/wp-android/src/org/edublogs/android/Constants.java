
package org.edublogs.android;

public class Constants { //APPCUSTUME Edit links (manual p.1)

    //public static String readerURL = "https://en.edublogs.org/reader/mobile/v2";  
    //public static String readerLoginURL = "http://edublogs.org/wp-login.php";
    //public static String helpURL = "http://help.edublogs.org/android/";

    public static String readerURL_v3 = "https://en.wordpress.com/reader/mobile/v2/?chrome=no"; //TODO: clear 
    public static String authorizedHybridHost = "en.wordpress.com";
    public static String readerTopicsURL = "http://en.wordpress.com/reader/mobile/v2/?template=topics";
    public static String readerDetailURL = "https://en.wordpress.com/wp-admin/admin-ajax.php?action=wpcom_load_mobile&template=details&v=2";
    
    //public static String wpcomXMLRPCURL = "http://edublogs.org/xmlrpc-JepexZakOe.php";
    //public static String wpcomLoginURL = "http://edublogs.org/wp-login.php";
    
    public static int QUICK_POST_PHOTO_CAMERA = 0;
    public static int QUICK_POST_PHOTO_LIBRARY = 1;
    public static int QUICK_POST_VIDEO_CAMERA = 2;
    public static int QUICK_POST_VIDEO_LIBRARY = 3;

    /**
     * User-Agent string used when making HTTP connections. This is used both for API traffic as
     * well as embedded WebViews.
     */
    public static final String USER_AGENT = "wp-android";
}
