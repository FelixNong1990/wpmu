package org.edublogs.android;

class Config {
  
    protected static final String OAUTH_APP_ID="wordpress";
  
    protected static final String OAUTH_APP_SECRET="wordpress";
  
    protected static final String DB_SECRET="wordpress";
  
    protected static final String OAUTH_REDIRECT_URI="http://wordpress.org";
  
    protected static final String GCM_ID="wordpress";
  
}
