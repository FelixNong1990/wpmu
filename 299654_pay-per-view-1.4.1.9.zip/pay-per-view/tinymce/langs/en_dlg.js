tinyMCE.addI18n("en.payperview", {
	title: "Pay Per View"
});