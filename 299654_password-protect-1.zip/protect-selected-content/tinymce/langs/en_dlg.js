tinyMCE.addI18n("en.protect", {
	title: "Password Protect"
});