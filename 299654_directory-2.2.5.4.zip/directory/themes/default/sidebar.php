<div id="sidebar"><!-- start #sidebar -->
	<div class="padder">

		<?php if ( is_active_sidebar( 'sidebar-default' ) ) : ?>
			<?php dynamic_sidebar( 'sidebar-default' ); ?>
		<?php endif; ?>

	</div>
</div><!-- end #sidebar -->