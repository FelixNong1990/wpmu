<?php

define( 'THEME_TEXT_DOMAIN', 'directory' );

include_once 'core/core.php';
include_once 'core/colors.php';
include_once 'core/options.php';