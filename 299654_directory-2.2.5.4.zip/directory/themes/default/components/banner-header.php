<div id="banner-header">
    <?php do_action( 'custom_banner_header' ); ?>
</div>