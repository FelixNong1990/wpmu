<?php get_header(); ?>

<div id="content"><!-- start #content -->
	<div class="padder">
		<div class="page 404">
			<?php locate_template( array( '/components/messages.php' ), true ); ?>
		</div>
	</div>
</div><!-- end #content -->

<?php get_footer(); ?>