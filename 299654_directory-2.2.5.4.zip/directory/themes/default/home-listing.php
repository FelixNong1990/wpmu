<?php get_header() ?>

<div id="content"><!-- start #content -->
    <div class="padder">
    <?php echo do_shortcode( '[dr_list_categories style="grid"]' ); ?>
    </div>
</div><!-- end #content -->

<?php get_footer() ?>